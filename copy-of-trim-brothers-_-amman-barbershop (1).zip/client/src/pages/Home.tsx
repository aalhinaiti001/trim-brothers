import { useEffect, useState, type ReactNode } from "react";
import {
  ArrowDownRight,
  ArrowUpRight,
  Clock3,
  Instagram,
  MapPin,
  Menu,
  MessageCircle,
  Navigation,
  Phone,
  Scissors,
  Star,
  X,
} from "lucide-react";

const contact = {
  phoneHref: "tel:+962796588891",
  whatsappHref: "https://wa.me/962796588891",
  instagramHref: "https://www.instagram.com/trim_brothers.962/",
  mapsHref:
    "https://www.google.com/maps/search/?api=1&query=Trim+Brothers+Hussein+Al-Yashein+Street+Amman+Jordan",
};

const images = {
  hero: "/manus-storage/trim-brothers-hero_fbb23210.jpg",
  fade: "/manus-storage/trim-brothers-fade_dcb6f376.jpg",
  beard: "/manus-storage/trim-brothers-beard_e4dbf767.jpg",
  space: "/manus-storage/trim-brothers-space_102c2dc5.jpg",
};

const navItems = [
  ["Home", "#home"],
  ["Services", "#services"],
  ["Our Work", "#work"],
  ["Visit Us", "#visit"],
] as const;

function Eyebrow({ children }: { children: ReactNode }) {
  return <span className="eyebrow">{children}</span>;
}

function ActionLink({
  href,
  children,
  variant = "dark",
  external = false,
}: {
  href: string;
  children: ReactNode;
  variant?: "dark" | "gold" | "ghost";
  external?: boolean;
}) {
  return (
    <a
      className={`action-link ${variant}`}
      href={href}
      target={external ? "_blank" : undefined}
      rel={external ? "noreferrer" : undefined}
    >
      {children}
      <ArrowUpRight size={17} strokeWidth={2.3} aria-hidden="true" />
    </a>
  );
}

function ServiceCard({
  number,
  name,
  description,
  image,
}: {
  number: string;
  name: string;
  description: string;
  image: string;
}) {
  return (
    <article className="service-card reveal">
      <div className="service-image-wrap">
        <img src={image} alt="" className="service-image" loading="lazy" />
      </div>
      <div className="service-copy">
        <span className="service-number">{number}</span>
        <h3>{name}</h3>
        <p>{description}</p>
      </div>
    </article>
  );
}

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const updateScroll = () => setScrolled(window.scrollY > 24);
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setMenuOpen(false);
    };

    updateScroll();
    window.addEventListener("scroll", updateScroll, { passive: true });
    document.addEventListener("keydown", closeOnEscape);
    return () => {
      window.removeEventListener("scroll", updateScroll);
      document.removeEventListener("keydown", closeOnEscape);
    };
  }, []);

  useEffect(() => {
    document.body.classList.toggle("menu-is-open", menuOpen);
    return () => document.body.classList.remove("menu-is-open");
  }, [menuOpen]);

  return (
    <div className="site-shell" id="home">
      <header className={`site-header ${scrolled ? "is-scrolled" : ""} ${menuOpen ? "is-menu-open" : ""}`}>
        <a href="#home" className="brand" aria-label="Trim Brothers home">
          <span className="brand-mark"><Scissors size={15} strokeWidth={1.8} /></span>
          <span className="brand-type">TRIM<small>BROTHERS</small></span>
        </a>

        <nav className="desktop-nav" aria-label="Primary navigation">
          {navItems.map(([label, href]) => (
            <a key={href} href={href}>{label}</a>
          ))}
        </nav>

        <div className="header-tools">
          <a
            className="instagram-button"
            href={contact.instagramHref}
            target="_blank"
            rel="noreferrer"
            aria-label="Trim Brothers on Instagram"
          >
            <Instagram size={19} />
          </a>
          <a className="top-cta" href={contact.whatsappHref} target="_blank" rel="noreferrer">
            Book on WhatsApp <ArrowUpRight size={15} />
          </a>
          <button
            className="menu-button"
            type="button"
            onClick={() => setMenuOpen((open) => !open)}
            aria-label={menuOpen ? "Close menu" : "Open menu"}
            aria-expanded={menuOpen}
            aria-controls="mobile-navigation"
          >
            {menuOpen ? <X size={22} /> : <Menu size={23} />}
          </button>
        </div>

        <div
          className={`mobile-menu ${menuOpen ? "is-open" : ""}`}
          id="mobile-navigation"
          aria-hidden={!menuOpen}
          aria-label="Mobile navigation"
        >
          {navItems.map(([label, href], index) => (
            <a key={href} href={href} onClick={() => setMenuOpen(false)} style={{ transitionDelay: `${index * 45}ms` }}>
              {label}<ArrowDownRight size={20} />
            </a>
          ))}
          <a className="mobile-book" href={contact.whatsappHref} target="_blank" rel="noreferrer">
            <MessageCircle size={18} /> Book on WhatsApp
          </a>
        </div>
      </header>

      <main>
        <section className="hero-section">
          <div className="hero-grain" aria-hidden="true" />
          <div className="hero-content wrap">
            <div className="hero-copy">
              <Eyebrow>Amman <i /> 962</Eyebrow>
              <h1><span>Trim</span><em>Brothers</em></h1>
              <p className="hero-kicker">More than a haircut.</p>
              <div className="hero-actions">
                <ActionLink href={contact.whatsappHref} variant="gold" external>
                  <MessageCircle size={18} /> WhatsApp us
                </ActionLink>
                <ActionLink href={contact.phoneHref} variant="ghost">
                  <Phone size={17} /> Call now
                </ActionLink>
              </div>
              <a className="hero-address" href="#visit">
                <MapPin size={18} /> Hussein Al-Yashein St., Amman
              </a>
            </div>

            <div className="hero-art reveal">
              <div className="hero-image-frame">
                <img src={images.hero} alt="A Trim Brothers barber at work in the shop" loading="eager" decoding="async" />
              </div>
              <div className="hero-tag tag-top">The chair<br />tells the story.</div>
              <div className="hero-tag tag-bottom">Good hair.<br />Better days.</div>
            </div>
          </div>
          <div className="hero-scroll"><span>Scroll to see the work</span><div /></div>
        </section>

        <section id="services" className="services-section section-wrap">
          <div className="brush-edge brush-edge-top" aria-hidden="true" />
          <div className="wrap">
            <div className="section-heading services-heading">
              <div>
                <Eyebrow>01 / What we do</Eyebrow>
                <h2>Our <em>services.</em></h2>
              </div>
              <p>Good work, no unnecessary extras. Just the detail your style deserves.</p>
            </div>
            <div className="services-grid">
              <ServiceCard number="01" name="Haircut" description="Classic & modern cuts. Tailored to you." image={images.hero} />
              <ServiceCard number="02" name="Fade" description="Sharp. Clean. On point." image={images.fade} />
              <ServiceCard number="03" name="Beard" description="Trim. Shape. Detail." image={images.beard} />
            </div>
          </div>
        </section>

        <section id="work" className="work-section section-wrap">
          <div className="work-title wrap">
            <Eyebrow>02 / Cuts from the chair</Eyebrow>
            <h2>The <em>work.</em></h2>
            <a href={contact.instagramHref} target="_blank" rel="noreferrer" className="follow-link">
              Follow @trim_brothers.962 <ArrowUpRight size={16} />
            </a>
          </div>

          <div className="work-collage wrap">
            <figure className="collage-card card-fade reveal">
              <img src={images.fade} alt="Close detail of a sharp fade haircut" loading="lazy" />
              <figcaption><span>Clean fades</span><b>01</b></figcaption>
            </figure>
            <div className="collage-statement reveal">
              <span className="slashed" aria-hidden="true" />
              <p>Clean fades<br /><em>real people.</em></p>
            </div>
            <figure className="collage-card card-space reveal">
              <img src={images.space} alt="Dark industrial interior of the barbershop" loading="lazy" />
              <figcaption><span>Inside the shop</span><b>02</b></figcaption>
            </figure>
            <figure className="collage-card card-beard reveal">
              <img src={images.beard} alt="Precise beard trimming detail" loading="lazy" />
              <figcaption><span>Detail matters</span><b>03</b></figcaption>
            </figure>
            <div className="collage-stamp reveal">Amman<br /><b>962</b></div>
          </div>
        </section>

        <section className="space-section section-wrap">
          <div className="space-image reveal">
            <img src={images.space} alt="A signature black barber chair at Trim Brothers" loading="lazy" />
          </div>
          <div className="space-copy">
            <Eyebrow>03 / The space</Eyebrow>
            <h2>Good people.<br /><em>Great cuts.</em></h2>
            <p>A neighborhood barbershop in Amman built around good work, familiar faces and a proper cut.</p>
            <div className="space-rule" />
            <span className="hand-note">Same chairs,<br />different stories.</span>
          </div>
        </section>

        <section className="proof-section section-wrap">
          <div className="wrap proof-grid">
            <div className="proof-main">
              <Eyebrow>04 / Rated on Google</Eyebrow>
              <div className="rating-number">4.9<span>/5</span></div>
              <div className="stars" aria-label="Five stars"><Star fill="currentColor" /><Star fill="currentColor" /><Star fill="currentColor" /><Star fill="currentColor" /><Star fill="currentColor" /></div>
              <p>121 Google reviews</p>
            </div>
            <blockquote>
              <span>“</span>
              Great service, professional<br />and friendly.
              <footer>— Google review</footer>
            </blockquote>
            <a className="proof-link" href="https://www.google.com/search?q=Trim+Brothers+Amman" target="_blank" rel="noreferrer">
              Read Google reviews <ArrowUpRight size={19} />
            </a>
          </div>
        </section>

        <section id="visit" className="visit-section section-wrap">
          <div className="wrap visit-grid">
            <div className="visit-head">
              <Eyebrow>05 / Visit us</Eyebrow>
              <h2>Come by.<br /><em>We’re open.</em></h2>
              <a className="directions-large" href={contact.mapsHref} target="_blank" rel="noreferrer">
                <Navigation size={19} /> Get directions <ArrowUpRight size={17} />
              </a>
            </div>
            <div className="visit-details">
              <div className="detail-row">
                <MapPin size={22} /><div><span>Find us</span><p>Hussein Al-Yashein St.<br />Amman, Jordan</p></div>
              </div>
              <div className="detail-row">
                <Clock3 size={22} /><div><span>Opening hours</span><p>Open daily<br />11:00 AM – 10:00 PM</p></div>
              </div>
              <div className="detail-row">
                <Phone size={22} /><div><span>Get in touch</span><p><a href={contact.phoneHref}>+962 79 658 8891</a><br /><a href={contact.instagramHref} target="_blank" rel="noreferrer">@trim_brothers.962</a></p></div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="site-footer">
        <div className="footer-brush" aria-hidden="true" />
        <div className="wrap footer-content">
          <div className="footer-brand"><Scissors size={20} /><span>TRIM<br />BROTHERS</span></div>
          <p>Amman, Jordan<br />More than a haircut.</p>
          <a href="#home" className="back-top">Back to top <ArrowUpRight size={15} /></a>
        </div>
      </footer>

      <div className="mobile-action-bar" aria-label="Quick contact actions">
        <a href={contact.phoneHref} aria-label="Call Trim Brothers"><Phone size={18} /> <span>Call</span></a>
        <a className="mobile-wa" href={contact.whatsappHref} target="_blank" rel="noreferrer" aria-label="Book on WhatsApp"><MessageCircle size={19} /> <span>WhatsApp</span></a>
        <a href={contact.mapsHref} target="_blank" rel="noreferrer" aria-label="Get directions to Trim Brothers"><MapPin size={19} /> <span>Directions</span></a>
      </div>
    </div>
  );
}
